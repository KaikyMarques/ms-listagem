package com.example.appduo

class ConteudoForma {
}