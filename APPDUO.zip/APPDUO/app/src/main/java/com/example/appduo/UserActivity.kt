package com.example.appduo

class UserActivity {
}